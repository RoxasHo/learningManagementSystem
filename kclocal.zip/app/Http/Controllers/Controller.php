<?php

namespace App\Http\Controllers;use Illuminate\Routing\Controller as BaseController;

abstract class Controller
{
    //
}

class Controller extends BaseController
{
    // Your controller code here
}
