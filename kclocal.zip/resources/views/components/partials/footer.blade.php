<footer class="p-5 bg-blue-500">
    <div class="text-white wrapper">
        <span>
            &copy Copyright 2021
        </span>
    </div>
</footer>
