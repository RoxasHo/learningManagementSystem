<img src="{{ asset('img/logo/logo.png') }}" {{ $attributes }} alt="">
